Jack Wanitkun CS350
Kruskal's Minimum Spanning Tree Algorithm
